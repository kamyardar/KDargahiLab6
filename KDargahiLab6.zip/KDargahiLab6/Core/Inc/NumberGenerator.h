/*
 * NumberGenerator.h
 *
 *  Created on: Nov 29, 2024
 *      Author: kamya
 */

#ifndef INC_NUMBERGENERATOR_H_
#define INC_NUMBERGENERATOR_H_

#include "stm32f4xx_hal.h"



uint32_t generator();

void numberGenerator_init();



#endif /* INC_NUMBERGENERATOR_H_ */
